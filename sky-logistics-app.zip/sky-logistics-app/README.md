# Sky Logistics App

This is a standalone prototype for the autonomous cognitive logistics mesh idea. It is intentionally separated from the Sky source materials and can be treated as its own small project.

## Run locally

Open [index.html](index.html) in a browser, or serve the folder with a simple static server.

Example:

```bash
cd "c:/Users/caitl/OneDrive/Desktop/sky-logistics-app"
python -m http.server 8000
```

Then open http://localhost:8000/.
